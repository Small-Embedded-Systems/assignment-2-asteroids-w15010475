/* Game state */
extern bool  playing;
