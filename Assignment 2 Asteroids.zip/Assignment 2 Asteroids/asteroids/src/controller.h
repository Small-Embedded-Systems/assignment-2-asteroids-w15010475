/*Referances to functions in Controller*/
void gameControls(void);
bool btnPressed(enum position b);
bool start(void);
bool startagain(void);
