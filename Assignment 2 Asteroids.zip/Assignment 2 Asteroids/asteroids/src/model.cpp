/* Asteroids model */
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

/* Hardware Platform Library */
#include "model.h"
#include "utils.h"
#include "asteroids.h"

//linked list for missiles
static const int missile_heapsize = 5;
static missile_t heap[missile_heapsize];
static missile_t *freenodes;

//linked list for asteroids
static const int asteroid_heapsize = 9;
static asteroid_t asteroid_heap[asteroid_heapsize];
static asteroid_t *asteroidfreenodes;

float current_life_timeAlive;
int total_timeAlive;
int lives;
bool shieldActive;
int shieldHealth = 3;

//ship data
float ship_start_x;
float ship_start_y;
int ship_heading;
float ship_headingRadians;
float point_x;
float point_y;
float ship_left_x;
float ship_left_y;
float ship_right_x;
float ship_right_y;

double ship_speed;
double acceleration;

static const float Dt = 0.01;
struct missile *missile_active = NULL;
struct asteroid *asteroid_active = NULL;

/*main physics for game. How ship moves, asteroids and bullets are added to their lists */
void physics(void) {
	checkShipHitAsteroid(asteroid_active);
	checkMissileHitAsteroid(missile_active,asteroid_active);
	
	updateMissile(missile_active);
	updateAsteroid(asteroid_active);
	
	screenWrap();
	spawnAsteroids();
	
	ship_headingRadians=radians(ship_heading); // Calculates radians of angle at the top of traingle
	point_x=15*(cos(ship_headingRadians));//calc
	point_y=15*(sin(ship_headingRadians));
	
	ship_left_x=(-5*(cos(ship_headingRadians)))-(5*(sin(ship_headingRadians)));
	ship_left_y=(-5*(sin(ship_headingRadians)))+(5*(cos(ship_headingRadians)));
	ship_right_x=(-5*(cos(ship_headingRadians)))-(-5*(sin(ship_headingRadians)));
	ship_right_y=(-5*(sin(ship_headingRadians)))+(-5*(cos(ship_headingRadians)));
	
	ship_start_x=ship_start_x+ship_speed*(cos(ship_headingRadians));
	ship_start_y=ship_start_y+ship_speed*(sin(ship_headingRadians));
	
	//increase time alive by 1 second
	current_life_timeAlive = current_life_timeAlive + Dt; //changed to use Dt as well (kept freezing.....)

  //increase the ship speed - check for the max speed (4) otherwise increase via the acceleration
	if(ship_speed<4){
		ship_speed=ship_speed+acceleration;
	}
	if(acceleration>0){
		acceleration=acceleration-0.1;
	}
	if(ship_speed>0){
		ship_speed=ship_speed-0.02;
	}
}

/* Initialises values before game starts
  - Where the ship spawns
  - Initial values for game physics
  - Shield status*/
void initialiseGame(void) {
	ship_start_x = 240;
	ship_start_y = 160;
	ship_heading = 90;
	
	current_life_timeAlive = 0;
	total_timeAlive = 0;
	shieldHealth=3;
	acceleration=0.0;
	shieldActive = true;
}

/* Wraps ship around the screen if it goes out the boundaries (Top, bottom, left and right) */
void screenWrap(void){
  if(ship_start_x > 480){
		ship_start_x = 5;
	} else if(ship_start_x < 0){
		ship_start_x = 475;
	} else if(ship_start_y > 280){
		ship_start_y = 35;
	} else if(ship_start_y < 34){
		ship_start_y =	260;
	}
}
/*Constucts a new missile*/
void spawnObject(struct missile *m){
    m->missile_x = ship_start_x;
    m->missile_y = ship_start_y;
    m->missile_vx = 200*(cos(ship_headingRadians));
    m->missile_vy = 200*(sin(ship_headingRadians));
    m->missile_ttl = 200;
}

/*Constructs a new asteroid*/
void spawnObject(struct asteroid *a){
    a->asteroid_x = randrange(10,470);
    a->asteroid_y = randrange(10,250);
    a->asteroidV_x = randrange(-5,15);
    a->asteroidV_y = randrange(-5,15);
    a->asteroid_ttl = randrange(900,1100);
}

void fireMissle(void){
	struct missile *spark = allocnode();
	if(spark) {
			spark->next = missile_active;
			missile_active = spark;
			spawnObject(spark);
	}
}

 void updateMissile(struct missile *m){
    for( ; m ; m = m->next ) {
        m->missile_x += m->missile_vx * Dt;
        m->missile_y += m->missile_vy * Dt;
        if( m->missile_x<32 || 480<m->missile_x ) m->missile_ttl=0;
        if( m->missile_y<32 || 260<m->missile_y ) m->missile_ttl=0;
        m->missile_ttl -= Dt;
        if( m->next->missile_ttl<=0 ) {
            struct missile *expired = m->next;
            m->next = m->next->next;
            freenode(expired);
        }
    }
}
 
void updateAsteroid(struct asteroid *a){
    for( ; a ; a = a->next ) {
        a->asteroid_x += a->asteroidV_x * Dt;
        a->asteroid_y += a->asteroidV_y * Dt;
        if( a->asteroid_x<-30|| 485<a->asteroid_x ) {
					a->asteroid_ttl=0;
				}
        if( a->asteroid_y<40 || 280<a->asteroid_y ) {
					a->asteroid_ttl=0;
					a->asteroid_ttl -= Dt;
				}
        if( a->next->asteroid_ttl<=0 ) {
            struct asteroid *expired = a->next;
            a->next = a->next->next;
            asteroidfreenode(expired);
        }
    }
}
 
void spawnAsteroids(void){
        struct asteroid *asteroidspark = asteroidallocnode();
        if(asteroidspark) {
            asteroidspark->next = asteroid_active;
            asteroid_active = asteroidspark;
            spawnObject(asteroidspark);
        }
}
 
/*Check to see if asteroid collides with the ship. Lowever lives by 1 if lives available*/
void checkShipHitAsteroid(struct asteroid *c){
    for( ; c ; c = c->next ) {
        if(c->asteroid_x<(ship_start_x+16) && c->asteroid_x>(ship_start_x-16)){
          if(c->asteroid_y<(ship_start_y+16) && c->asteroid_y>(ship_start_y-16)){
						if (shieldHealth >= 0) {
							shieldHealth--;
						}

						if(lives > -1 && shieldHealth < 0){
							lives--;
							total_timeAlive=total_timeAlive+current_life_timeAlive;
						}
						//destroy asteroid that was hit (make it move outside of boundary so it disapears)
						//c->asteroid_ttl = 0;
						c->asteroid_x = 500;
						c->asteroid_y = 500;
          }
        }
    }//end for
}

void checkMissileHitAsteroid(struct missile *a, struct asteroid *b) {
  for(; a ; a = a->next){
    for(; b ; b = b->next){
      if(a->missile_x > (b->asteroid_x-12) && a->missile_x < (b->asteroid_x+12)){
        if(a->missile_y > (b->asteroid_y-12) && a->missile_y < (b->asteroid_y+12)){
          
					a->missile_x = 500;//outside of play (destroys)
					a->missile_y = 500;
          b->asteroid_ttl=0;
        }
      }
		}//end for2
	}//end for1
 }

 /*heap for missiles*/
void initialise_heap(void){
    int n;
    for( n=0 ; n<(missile_heapsize-1) ; n++) {
        heap[n].next = &heap[n+1];
    }
    heap[n].next = NULL;
    freenodes = &heap[0];
}

missile_t *allocnode(void){
    missile_t *node = NULL;
    if( freenodes ) {
        node = freenodes;
        freenodes = freenodes->next;
    }
    return node;
}

void freenode(missile_t *n){
    n->next = freenodes;
    freenodes = n;
}

/*heap for asteroids*/
void initialise_asteroid_heap(void){
    int n;
    for( n=0 ; n<(asteroid_heapsize-1) ; n++) {
        asteroid_heap[n].next = &asteroid_heap[n+1];
    }
    asteroid_heap[n].next = NULL;
    asteroidfreenodes = &asteroid_heap[0];
}

asteroid_t *asteroidallocnode(void){
    asteroid_t *node = NULL;
    if( asteroidfreenodes ) {
        node = asteroidfreenodes;
        asteroidfreenodes = asteroidfreenodes->next;
    }
    return node;
}

void asteroidfreenode(asteroid_t *n){
    n->next = asteroidfreenodes;
    asteroidfreenodes = n;
}
